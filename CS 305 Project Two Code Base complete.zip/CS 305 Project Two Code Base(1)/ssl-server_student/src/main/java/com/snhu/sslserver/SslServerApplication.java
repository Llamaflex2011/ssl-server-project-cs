package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {
	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
}

@RestController
class CheckSumController {
  
    private final String DATA = "[nick galan]";

    @GetMapping("/hash")
    public String displayChecksum() {
        String hashValue = generateChecksum(DATA);
        return "<p>Data: " + DATA + "</p>" +
               "<p>Algorithm: SHA-256</p>" +
               "<p>Checksum (Hex): " + hashValue + "</p>";
    }

    private String generateChecksum(String data) {
        try {
            // 1. Initialize MessageDigest with SHA-256 algorithm
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            
            // 2. Generate the hash byte array from the unique data string
            byte[] encodedHash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            
            // 3. Convert byte array to a readable Hex string
            return bytesToHex(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Algorithm not found", e);
        }
    }

    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}